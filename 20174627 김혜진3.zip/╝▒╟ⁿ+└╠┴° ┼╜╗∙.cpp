#include <stdio.h>

void printList(int s, int e);

static int list[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

int binarySearchByIterative(int searchKey, int low, int high) {

        int searchedIndex = -1;

        int mid;

        while (low < high) {

                printf("�� ����Ʈ �������� �˻� : "); 

                printList(low, high);

                mid = (low + high) / 2;

                if (searchKey > list[mid])

                        low = mid + 1;

                else if (searchKey < list[mid])

                        high = mid -1;

                else {

                        searchedIndex = mid;

                        printf("index = %d���� %d ã��\n", searchedIndex, list[searchedIndex]);

                        break;

                }

        }

        return searchedIndex;

}

void printList(int s, int e) {

        int i;

        for(i=s; i<=e; i++){

                printf("%d ", list[i]);

        }

        printf("\n");

}

static int listt[] = {9, 1, 3, 8, 5, 6, 4, 7, 2};

int linearSearch(int searchKey, int size) {

        int i;

        for (i=0; i<size; i++) {

                printf("index = %d�� %d�� Ű %d�� ��\n", i, listt[i], searchKey);

                if (searchKey == listt[i]) {

                        printf("index = %d���� %d ã��\n", i, listt[i]);

                        return i;

                }

        }

        return -1;

}

void printListt(int q, int w) {

        int i;

        for(i=q; i<=w; i++){

                printf("%d ", listt[i]);

        }

        printf("\n");

}


       
int main() {

        int a, index;

        printf("==================== ����Ž��================= \n");

        printList(0, 9);

        printf("1-10������ ������ ã���� �ϴ� �� �Է� : ");

        scanf("%d", &a);

        index = binarySearchByIterative(a, 0, 9);

        if(index != -1)

                printf("index = %d, value = %d\n", index, list[index]);

        else

                printf("ã�� ���� ����.\n");
        
         int e, indexx;

        printf("=================== ����Ž��================= \n");

        printList(0, 8);

        printf("1-9������ ������ ã���� �ϴ� �� �Է� : ");

        scanf("%d", &e);

        index = linearSearch(e, 9);

        if(index != -1)

                printf("indexx = %d, value = %d\n", index, listt[indexx]);

        else

                printf("ã�� ���� ����.");
                
        return 0;

}

		
		


