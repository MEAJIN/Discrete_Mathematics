#include <stdio.h>

int set[]={1,2,3,4};

#define N 4

main()
{
    int i,j,k,l;
    for(l=0;l<N;l++){
    for(i=0;i<N;i++){
        if(l==i) continue;
        for(j=0;j<N;j++){
            if(i==j) continue;
            if(l==j) continue;
            for(k=0;k<N;k++){
                if(i==k) continue;
                if(j==k) continue;
                if(l==k) continue;
                printf("%d-%d-%d-%d\n",set[l],set[i],set[j],set[k]);
            }
        }
    }
    }
    return 0;
}
