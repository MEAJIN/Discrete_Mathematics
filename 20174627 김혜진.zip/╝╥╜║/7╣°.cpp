#include <stdio.h>

void va() {
	int a[2][4] = { {4,5,1,-2},{4,7,-7,5} };
	int b[4][3] = { {1,3,0},{-1,1,-4},{5,6,2},{3,5,3} };
	int e[2][3];

	int i, j, k;
	int sum;

	for (i = 0; i < 2; i++) {
		for (j = 0; j < 3; j++) {
			sum = 0;
			for (k = 0; k < 4; k++) {
				sum += a[i][k] * b[k][j];
			}
			e[i][j] = sum;
		}
	}

	for (i = 0; i < 2; i++) {
		for (j = 0; j < 3; j++) {
			printf("%d\t", e[i][j]);
		}
		printf("\n");
	}

}

int main(void) {
	va();
	return 0;
}