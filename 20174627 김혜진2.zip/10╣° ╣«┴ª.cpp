#include <stdio.h>

int main(void) {
	int aa[3][3] = { {1,0,1},
					 {0,1,0},
					 {0,0,0} };
					 
	int bb[3][3] = { {0,1,0},
					 {1,0,0},
					 {0,0,1} };

	int i, j;

	for (i = 0; i < 3; i++)
	{
		for (j = 0; j < 3; j++)
		{
			printf("%d ", aa[i][j] + bb[i][j]);
		}
		printf("\n");
	}
		printf("a�� b�� ����");
		printf("\n"); printf("\n");

	int q, w;

	for (q = 0; q < 3; q++)
	{
		for (w = 0; w < 3; w++)
		{
			printf("%d ", aa[q][w] * bb[q][w]);
		}
		printf("\n");
	}
		printf("a�� b�� ����");
}


